plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val apiBaseUrl = (System.getenv("API_BASE_URL") ?: "").trim().trimEnd('/')

android {
    namespace = "com.storymate.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.storymate.ai"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "API_BASE_URL", "\"${apiBaseUrl}\"")
    }
    buildFeatures {
        buildConfig = true
    }
}

kotlin {
    jvmToolchain(17)
}
