package com.storymate.ai

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.content.Context
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 17, 28)
    private val panel = Color.rgb(24, 30, 46)
    private val accent = Color.rgb(139, 92, 246)
    private val white = Color.rgb(245, 247, 255)
    private val muted = Color.rgb(165, 174, 196)
    private val executor = Executors.newSingleThreadExecutor()
    private val history = mutableListOf<JSONObject>()
    private lateinit var chatColumn: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        loadHistory()
        buildUi()
        if (history.isEmpty()) {
            addBubble("Hi! Main StoryMate hoon. 😊\n\nTum mujhse normal chat kar sakte ho, koi story idea discuss kar sakte ho, ya chapter likhwa/continue karwa sakte ho.", false, false)
        } else {
            history.forEach { addBubble(it.optString("content"), it.optString("role") == "user", false) }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(12), dp(16), dp(10))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(TextView(this).apply {
            text = "StoryMate"
            textSize = 24f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        })
        titleBox.addView(TextView(this).apply {
            text = "Your AI chat & story partner"
            textSize = 12f
            setTextColor(muted)
        })
        top.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        val clear = Button(this).apply {
            text = "New chat"
            textSize = 12f
            setTextColor(white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel))
            setOnClickListener {
                history.clear()
                getSharedPreferences("storymate", MODE_PRIVATE).edit().remove("history").apply()
                chatColumn.removeAllViews()
                addBubble("New chat started. Kya soch rahe ho aaj?", false, false)
                status.text = "Ready"
            }
        }
        top.addView(clear)
        root.addView(top)
        status = TextView(this).apply {
            text = if (BuildConfig.API_BASE_URL.isBlank()) "Setup needed: backend URL missing" else "Ready"
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(status)
        scroll = ScrollView(this).apply { isFillViewport = false }
        chatColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(12))
        }
        scroll.addView(chatColumn)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(4), dp(4))
            background = rounded(panel, 18)
        }
        input = EditText(this).apply {
            hint = "Message StoryMate…"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 16f
            minLines = 1
            maxLines = 4
            setPadding(dp(10), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.TRANSPARENT)
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false
            }
        }
        composer.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        send = Button(this).apply {
            text = "Send"
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
            setOnClickListener { sendMessage() }
        }
        composer.addView(send)
        root.addView(composer)
        setContentView(root)
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        if (BuildConfig.API_BASE_URL.isBlank()) {
            addBubble("Backend URL abhi set nahi hai. GitHub repository variable API_BASE_URL set karke workflow dobara run karo.", false, true)
            return
        }
        input.setText("")
        history.add(JSONObject().put("role", "user").put("content", text))
        addBubble(text, true, false)
        saveHistory()
        send.isEnabled = false
        status.text = "StoryMate is thinking…"
        val waitBubble = addBubble("Soch raha hoon…", false, true)
        executor.execute {
            try {
                val conn = (URL(BuildConfig.API_BASE_URL + "/api/chat").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 70000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                val body = JSONObject().put("messages", JSONArray(history)).toString()
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val responseText = stream.bufferedReader().use { it.readText() }
                val json = JSONObject(responseText)
                if (code !in 200..299) throw Exception(json.optString("error", "Server error ($code)"))
                val reply = json.optString("reply", "Empty reply")
                runOnUiThread {
                    chatColumn.removeView(waitBubble)
                    history.add(JSONObject().put("role", "assistant").put("content", reply))
                    addBubble(reply, false, false)
                    saveHistory()
                    status.text = "Ready"
                    send.isEnabled = true
                }
                conn.disconnect()
            } catch (e: Exception) {
                runOnUiThread {
                    chatColumn.removeView(waitBubble)
                    addBubble("Error: ${e.message ?: "Could not connect"}\n\nInternet, backend URL, aur Gemini service check karo.", false, true)
                    status.text = "Could not complete request"
                    send.isEnabled = true
                }
            }
        }
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
    }

    private fun addBubble(text: String, isUser: Boolean, isError: Boolean): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (isUser) Gravity.END else Gravity.START
            setPadding(0, dp(4), 0, dp(4))
        }
        val bubble = TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(if (isError) Color.rgb(255, 190, 190) else white)
            setPadding(dp(13), dp(10), dp(13), dp(10))
            background = rounded(if (isUser) Color.rgb(74, 55, 145) else panel, 16)
            maxWidth = resources.displayMetrics.widthPixels * 8 / 10
        }
        row.addView(bubble)
        chatColumn.addView(row)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return row
    }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun saveHistory() {
        val arr = JSONArray()
        history.takeLast(40).forEach { arr.put(it) }
        getSharedPreferences("storymate", MODE_PRIVATE).edit().putString("history", arr.toString()).apply()
    }

    private fun loadHistory() {
        try {
            val raw = getSharedPreferences("storymate", MODE_PRIVATE).getString("history", null) ?: return
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) history.add(arr.getJSONObject(i))
        } catch (_: Exception) {}
    }
}
